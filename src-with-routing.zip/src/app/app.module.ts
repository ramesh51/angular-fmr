import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { HttpModule } from "@angular/http";
import { SearchComponent } from './search/search.component';
import { DistancePipe } from './pipes/distance.pipe';
import { DetailsComponent } from './details/details.component';
import { RouterModule, Routes } from '@angular/router';
import { Page1Component } from './page1/page1.component';
import { ErrorComponent } from './error/error.component';

const routeConfig = [
  { path: 'search', component: SearchComponent },
  { path: 'page1', component: Page1Component },
  { path: '**', component: ErrorComponent }]
@NgModule({
  declarations: [
    AppComponent,
    SearchComponent,
    DistancePipe,
    DetailsComponent,
    Page1Component,
    ErrorComponent
  ],
  imports: [
    BrowserModule, FormsModule, HttpModule,
    RouterModule.forRoot(
      routeConfig,
      { enableTracing: true } // <-- debugging purposes only
    )
  ],
  providers: [],
  bootstrap: [AppComponent] //whats the first component to start with??
})
export class AppModule { }
