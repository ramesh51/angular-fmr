export class Criteria{//model
  query:string;
  limit:number;
}