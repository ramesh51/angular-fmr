function foo(age) {
  console.log(age);
  console.log(arguments[0], arguments[1]);
  //ALT+SHIFT+F
  var age = 'fidelity';
  // console.log(age.substr(0, 2));
  // console.log(age.length);
  // age = 1;
  //  console.log(age.substr(0, 2));
  // console.log(age.length);
  // age = true;
  // console.log(age.substr(0, 2));
  return age+1;
}
var result = foo(12 , 'fmr', true);
console.log(result);
foo(12 , 'fmr');

Foo();