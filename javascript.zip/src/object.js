var a=1;
var user = {
  fname:'Ram',
  age:3
};
console.log(user);
user.salary=23;
console.log(user);
delete user.fname;
console.log(user);

//chrome = V8
// IE = chakra
// FF = Mozilla