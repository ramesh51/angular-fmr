var marks = [23,45,10,56,-1, 1,7];
console.log(marks[2]);
marks.push(-3);
console.log(marks);
// marks.pop();
// console.log(marks);
// marks.splice(2, 1);
// marks.sort(function(number1, number2){
//   return number2 - number1;//-ve, 0, +ve
// });
var result = marks.filter(function(number, index){
  console.log(number, index);
  // return number>0;
  return number%2 ===1;
})
console.log(marks);
console.log(result);