import { Component, OnInit } from '@angular/core';
import { SearchService } from "../services/search.service";
@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css'],
  providers: [SearchService]
})
export class SearchComponent implements OnInit {
  songs:any;
  search() {
    //web service
    var observable = this.service.fetch();
    observable.subscribe(function (response) {//called when statusCode [100 to 399]
      console.log(response.json().results);
      this.songs=response.json().result
    });
    console.log(this.songs);
  }
  constructor(public service: SearchService) { }

  ngOnInit() {
  }

}