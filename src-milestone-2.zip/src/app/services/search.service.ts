import { Injectable } from '@angular/core';
import { Http } from "@angular/http";
@Injectable()
export class SearchService {
  fetch() {
    console.log('fetch called ....')
      ;
    var observable = this.http.get('https://itunes.apple.com/search?term=jack+johnson&limit=25');
    return observable;
  }
  constructor(public http: Http) { }
}
