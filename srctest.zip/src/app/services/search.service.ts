import { Injectable } from '@angular/core';
import { Http } from "@angular/http";
@Injectable()
export class SearchService {
  fetch(query:string, limit:number) {
    console.log('fetch called ....')
      ;
    var observable = this.http.get('https://itunes.apple.com/search?term='+query+'&limit='+limit);
    return observable;
  }
  constructor(public http: Http) { }
}

// var a={
//   fname:'ram',
//   addresses:[{

//   },
//   {

//   }]
// };