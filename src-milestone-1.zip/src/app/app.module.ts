import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { SearchComponent } from './search/search.component';
@NgModule({
  declarations: [
    AppComponent,
    SearchComponent 
  ],
  imports: [
    BrowserModule, FormsModule//2
  ],
  providers: [], 
  bootstrap: [AppComponent] //whats the first component to start with??
})
export class AppModule { }
