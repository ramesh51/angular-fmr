export class Criteria{
  query:string;
  limit:number;
}