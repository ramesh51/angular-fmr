import { Component, OnInit } from '@angular/core';
import { Criteria } from "../Criteria";

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  songs: Criteria[] = [];
  criteria: Criteria = {
    query: 'ram',
    limit: 2
  }; //1
  search() {
    // console.log(this.query);
    // this.query='Ramesh';
    var copy = Object.assign({}, this.criteria); //create copy 
    this.songs.push(copy);
  }
  deleteRow(index){
    var decision = confirm('Are you sure??');
    if(decision)
      this.songs.splice(index,1 );
  }
  constructor() { }

  ngOnInit() {
  }

}
