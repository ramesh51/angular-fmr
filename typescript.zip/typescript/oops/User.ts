class User {
  fname: string;
  age: number;
  constructor(fname1: string) {
    this.fname = fname1;
  }
  walk(){
    console.log(this.fname+ ' is walking...');
    this.run();
  }
  private run(){
    console.log('private method called..');
  }
}

var u1 = new User('ram');
console.log(u1.fname);
u1.walk();
function createUser(size): User[] {
  var users: User[] = [];
  for (var i = 1; i <= size; i++) {
    var user = new User('Ram' + i)
    user.age = i * 10;
    users.push(user);
  }
  return users;
}
var users = createUser(5);
users.sort(function(u1:User, u2:User){
  return u2.age - u1.age;
})

console.log(users);
var a :number;
// a=true;
a=1;