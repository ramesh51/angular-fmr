var User = /** @class */ (function () {
    function User(fname1) {
        this.fname = fname1;
    }
    return User;
}());
var u1 = new User('ram');
console.log(u1.fname);
function createUser(size) {
    var users = [];
    for (var i = 1; i <= size; i++) {
        var user = new User('Ram' + i);
        user.age = i * 10;
        users.push(user);
    }
    return users;
}
var users = createUser(5);
users.sort(function (u1, u2) {
    return u2.age - u1.age;
});
console.log(users);
