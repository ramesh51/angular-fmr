console.log('hello');
var str:number; //string, boolean , Date, any
str = 1;

// function add(a:number , b:number):number{
//   return a+b;
// }
// console.log(add(2,3));

function addAll( allNumbers:number[]):number{
  var total=0;
  allNumbers.forEach(function(element, index){
    if(index%2===1)
     total=total + element;
  })
  return total;
}
console.log(addAll([1,2,3,4,5,7,9,5]));