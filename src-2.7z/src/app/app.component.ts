import { Component } from '@angular/core';
@Component({ //meta data, decorator
  selector: 'app-root',
  templateUrl: './app.component.html', //template
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
}
