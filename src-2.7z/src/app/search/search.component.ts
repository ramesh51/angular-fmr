import { Component, OnInit } from '@angular/core';
import { SearchService } from "../services/search.service";
@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css'],
  providers: [SearchService]
})
export class SearchComponent implements OnInit {
  songs: any;//state
  query: string = 'jagjit';
  limit: number;
  showError:boolean=false;//1
  search() {//behavior
    this.showError=false;//2
    //call web service
    var observable = this.service.fetch(this.query, this.limit);
    observable.subscribe((response) => {//called when statusCode [100 to 399]
      console.log(response.json().results);
      this.songs = response.json().results;
      console.log(this.songs);
    },
  (error)=> { //error callback, called when statusCode 400+
    this.showError=true;//3
  });
  }
  toggle: boolean; //true:ascending
  sortByPrice() {
    this.songs.sort((song1, song2) => {
      return this.toggle ? song2.collectionPrice - song1.collectionPrice : song1.collectionPrice - song2.collectionPrice;
    });
    this.toggle = !this.toggle;
  }
  constructor(public service: SearchService) { }

  ngOnInit() {
  }

}